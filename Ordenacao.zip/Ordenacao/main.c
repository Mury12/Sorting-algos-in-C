/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: Gabriel
 *
 * Created on 20 de março de 2019, 15:01
 */

#include <stdio.h>
#include <stdlib.h>
#include "Ordena.h"

/*
 * 
 */
int main(int argc, char** argv) {
    Ordena();
    return (EXIT_SUCCESS);
}

