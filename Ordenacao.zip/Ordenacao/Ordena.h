void Ordena();
void bubbleSort(int *vet, int qtdd);
void bubbleSortInt(int *vet, int qtdd);
void SelectionSort(int *vet, int qtdd);
void InsertionSort(int *vet, int qtdd);