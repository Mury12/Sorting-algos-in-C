void Ordena();
void bubbleSort(int *vet, int qtdd);
void bubbleSortInt(int *vet, int qtdd);
void SelectionSort(int *vet, int qtdd);
void InsertionSort(int *vet, int qtdd);
void MergeSort(int *vet, int inicio, int qtdd);
void Merge(int *vet, int inicio, int meio, int qtdd);
void QuickSort(int *vet,int inicio, int qtdd);
int Particiona(int *vet,int inicio,int qtdd);