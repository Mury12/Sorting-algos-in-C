/* 
 * File:   main.c
 * Author: Gabriel
 * Created on 23 de abril de 2019, 13:29
 */

#include <stdio.h>
#include <stdlib.h>
#include"ArvoreBinaria.h"



int main() {
    int op,x,valor;
    ArvBin *raiz = cria_ArvBin();
    while(op!=0){
        printf("----------------------------------------");
        printf("MENU ARVORE BINARIA");
        printf("----------------------------------------");
        printf("\nSelecione o que quer fazer na árvore binaria\n");
        printf("1-Inserir Valor\n");
        printf("2-Consultar Valor\n");
        printf("3-Altura árvore\n");
        printf("4-Imprimir\n");
        printf("5-Total de Nós\n");
        printf("6-Remover Valor\n");
        printf("7 - Destruir Arvore binaria\n");
        scanf("%d",&op);
    
    
    switch(op){
        case(1):
           
            printf("Digite o valor a ser inserido\n");
            scanf("%d",&valor); 
            x=insere_ArvBin(raiz,valor);
            if(x=0){
                printf("O Valor não pode ser Inserido\n");
            }else{
                printf("Valor Inserido com Sucesso\n");
            }
            break;
        
        case(2):
            printf("Digite o Valor para consulta\n");
            scanf("%d",&valor); 
            x=consulta_ArvBin(raiz, valor);
            
        break;
        
        case(3):
            x=altura_ArvBin(raiz);
            printf("o valor da altura e: %d", x);
        break;
        
        
        case(4):
            printf("Pre Ordem\n");
            preOrdem_ArvBin(raiz);
            printf("Em Ordem\n");
            emOrdem_ArvBin(raiz);
            printf("Pos Ordem\n");
            posOrdem_ArvBin(raiz);
        break;
        
        case(5):
            x=totalNO_ArvBin(raiz);
            printf("o total de nós e: %d", x);
        break;
        
        case(6):
            printf("Digite o Valor para Remoção\n");
            scanf("%d",&valor);
            x=remove_ArvBin(raiz, valor);
        break;
        
    }
    
    

    }
}