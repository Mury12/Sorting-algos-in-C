#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "canvas.h"

#define null NULL
#define true 1
#define false 0

int main() 
{

    return start();

}

