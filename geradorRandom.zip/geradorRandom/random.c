/*
 * File:   random.c
 * Author: Gabriel
 *
 * Created on 12 de março de 2019, 15:50
 */

#include <stdio.h>
#include <stdlib.h>
#include "randomh.h"


void randomico(int *num, int quantNum, int Lim) {
    
    srand(time(NULL));
    for(int i=0;i<quantNum;i++){
        
        num[i] = rand() %Lim;
    }
      
    gravaArq(num,quantNum);
    
    
}

void gravaArq(int *num, int quantNum){

    FILE *arq;
    arq = fopen("aleatorios.txt","w");
    if(arq == NULL){
        printf("Erro ao Abrir o Arquivo\n");
        
    }else{
        for(int i=0;i<quantNum;i++){ 
            fprintf(arq,"%d ",num[i]);
        }
    }
   fclose(arq); 

}