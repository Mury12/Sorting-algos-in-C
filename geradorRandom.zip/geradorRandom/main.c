

/* 
 * File:   main.c
 * Author: Gabriel
 *
 * Created on 12 de março de 2019, 15:25
 */

#include <stdio.h>
#include <stdlib.h>
#include "randomh.h"

int main(int argc, char** argv) {
    int lim,qtdd;
    printf("Digite a quantidade de numeros que voce quer preencher\n");
    scanf("%d",&qtdd);
    int*num = (int *)malloc(qtdd*sizeof(int));
    printf("Digite o limite de numeros\n");
    scanf("%d",&lim);
    randomico(num,qtdd,lim);
    return (0);
}

