
/* 
 * File:   random.h
 * Author: Gabriel
 *
 * Created on 12 de março de 2019, 15:29
 */


void randomico(int *num, int quantNum, int Lim);
void gravaArq(int *num, int quantNum);