#ifndef RB_BTREE_H
#define RB_BTREE_H
#include "./btree.h"
#include "./rbtree.h"

/**
 * Exibe as propriedades da árvore
 * 234
 */
void check_234_tree(Tree_234 *t);
//manipula a conversão
RB_Tree convert_234_rb(Tree_234 *t);
/**
 * Cria um nó no tipo rubro negro
 * retorna o nó mais significante (que sobe)
 */
RB_Node * make_rb_node(Node_234 * n);
/**
 * Trata a criação de um nó RB para
 * o nó 234 com dois filhos
 */
RB_Node * two_node(Node_234 * n);
/**
 * Trata a criação de um nó RB para
 * o nó 234 com tres filhos
 */
RB_Node * three_node(Node_234 * n);
/**
 * Trata a criação de um nó RB para
 * o nó 234 com quatro filhos
 */
RB_Node * four_node(Node_234 * n);
/**
 * Trata a criação de um nó RB para
 * o nó 234 folha
 */
RB_Node * leaf_node(Node_234 * n);
/**
 * Faz a interação com o algorítmo
 * de conversão
 */
Tree_234 *  convert_rb_234(RB_Tree * t);
/**
 * Faz a varredura da árvore
 * 234 a partir da raíz
 */
RB_Tree  walk_234_tree(Tree_234 * t);
/**
 * Faz a varredura de um nó
 * e de suas sub árvores
 */
RB_Node * walk_234_nodes(Node_234 * n);

#endif