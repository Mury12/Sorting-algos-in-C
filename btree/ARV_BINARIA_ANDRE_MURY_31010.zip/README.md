# EXECUÇÃO
 - No diretório do projeto 

    `gcc *.c **/*.c -o main -lm`

    `./main`;

# Author

 - André Mury de Carvalho - 31010 - SIN